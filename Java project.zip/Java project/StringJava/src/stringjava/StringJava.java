
package stringjava;

import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author benie
 */
public class StringJava {

      /**
       * @param args the command line
       * arguments
       */
      public static void main(String[] args) {
      
            Scanner scan = new Scanner(System.in);
            
//            int age = Integer.parseInt(JOptionPane.showInputDialog("Enter your age")); 
//JOptionPane.showMessageDialog(null,"you're "+age+" years old");

            String characters;//[]= new String[1];
            System.out.println("Enter a name:");
             characters = scan.nextLine();
           
    //String string = "characters ";  
  
        //Displays individual characters from given string  
        System.out.println("Individual characters from given string: ");  
  
        //Iterate through the string and display individual character  
        for(int i = 0; i < characters.length(); i++){  
            System.out.print(characters.charAt(i) + ",");  
        }           
      }
      
}
