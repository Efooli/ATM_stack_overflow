
package bro_audioplayer;
import javax.sound.sampled.*;
import java.io.File;
import java.io.IOException;
import java.util.Scanner;


/**
 *
 * @author benie
 */
public class Bro_audioPlayer {

      /**
       * @param args the command line
       * arguments
       * @throws javax.sound.sampled.UnsupportedAudioFileException
       * @throws java.io.IOException
       * @throws javax.sound.sampled.LineUnavailableException
       */
      public static void main(String[] args) throws UnsupportedAudioFileException,IOException, LineUnavailableException {
            
                  // TODO code application logic here
              Scanner scan = new Scanner(System.in);
                  File file = new File("C:\\Users\\benie\\OneDrive\\Documents\\SFD260\\Fr_Nathan.wave");
                  
                  AudioInputStream audioStream = AudioSystem.getAudioInputStream(file);
                  Clip clip = AudioSystem.getClip();
                  clip.open(audioStream);
                  clip.start();
                  String response = scan.next();
            
            
      }
      
}
