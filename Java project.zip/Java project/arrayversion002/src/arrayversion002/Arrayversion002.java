
package arrayversion002;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class Arrayversion002{

            public static void main(String[] args) {
            Arrayversion002 names = new Arrayversion002();
            Scanner in = new Scanner(System.in);
            
     String size = JOptionPane.showInputDialog("enter the size");
            int index = Integer.parseInt(size);
            
            String[] educationRd = new String[index];
            
            names.collectingnames(educationRd);
            names.Display(educationRd);

                  
                  
                  
                  
      }
            
            public void collectingnames(String[]educationRd)
            {
                  //char repeat ='y';
                  String userAnswer,name;
                  int k;
             Scanner in = new Scanner(System.in);
             //String[] educationRd = new String[10];
             do
             {
               
                System.out.println("What's your streetNum");
                int StreetNum = in.nextInt();
                if(educationRd[StreetNum]==null)
                {
                System.out.println("What's your name");
                name = in.next();  
                educationRd[StreetNum]= name;
                //educationRd[2]=name;
                System.out.println("do you want to continue?");
                userAnswer = in.next();
                
                }else
                {
                 userAnswer="yes" ;
              System.out.println("This number is already used");
                 
                }
                
               
                //repeat=in.next().charAt(0);
                
                   
             }while(userAnswer.equalsIgnoreCase("yes"));
             
          
 
             
}
            //Display method
           public void Display(String[]educationRd)
            {
                  int i;
               for(i=0; i<educationRd.length; i++)
               {
                System.out.printf("[%d]=%s\n",i,educationRd[i]);
               }
            }
 
}
