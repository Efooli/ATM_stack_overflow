
package bro_writingtoafile;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;
import java.util.Scanner;
import javax.swing.JOptionPane;


public class Bro_WritingToAfile {

     
      public static void main(String[] args) {
                   Scanner x = new Scanner(System.in);
       Random r = new Random();

int position = Integer.parseInt(JOptionPane.showInputDialog("Enter a position"));
       String name[]= new String[position];
       
        System.out.println("please write something");
            int i;
       for(i=0; i<name.length; i++){
            name[i]= x.nextLine();
      }
       
       
      
      try {
            FileWriter writer = new FileWriter("C:\\Users\\benie\\OneDrive\\Documents\\SFD260\\Prince_beni.csv");
           //writer.write("Rose are red\ncool\nokay\ncome\n");
     for(i=0; i<name.length; i++){
            //System.out.println(writer.name[i]);
           writer.write("\n "+name[i]);
     }      
           writer.append("\n\n(Beni le prince)");
           writer.close();
     } catch (IOException e) {
           e.printStackTrace();
     }
            
            
      }
      
}
