
package beniarraylist;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author benie
 */
public class BeniArrayList {

      
      public static void main(String[] args) {
     int i;
            Scanner scan = new Scanner(System.in);
           // String name[] = new String[2];
            
    ArrayList<String> list=new ArrayList<String>();//Creating arraylist    
      list.add("Mango");//Adding object in arraylist    
      list.add("Apple");    
      list.add("Banana");    
      list.add("Grapes"); 
      
      
      
     // list.add(10);
      
      //cars.remove(0);//removing an element
      //cars.set(0, "Opel");// to modify an element
      //Printing the arraylist object  
 
      // ============ scanner ==========
//      System.out.println("Enter the name of the account user1");
//      list.add(scan.nextLine());
//      System.out.println("Enter the name of the account user2");
//      list.add(scan.nextLine());
//for (i = 0; i < name.length; i++){
//      list.add(scan.nextLine());
//      }

//=================== end ===================
        
      System.out.println(list);  
      //System.out.println(list.get(0));// printing the array of zero
      
//=============== for loops ====================
      // for (int i = 0; i < list.size(); i++) {
      //System.out.println(list.get(i));
    //}
    
//    for (String i : list) {
//      System.out.println(i);
//    }
            
      }
      
}
