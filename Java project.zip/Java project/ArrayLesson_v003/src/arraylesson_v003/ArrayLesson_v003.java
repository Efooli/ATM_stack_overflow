package arraylesson_v003;
import java.util.*;


public class ArrayLesson_v003 {

      static int index;
      public static void main(String[] args){
       
           Random rand = new Random();
           Scanner n = new Scanner(System.in);
           ArrayLesson_v003 object = new ArrayLesson_v003();
           Boolean_T_and_F Bool = new Boolean_T_and_F();
           int position ;
           boolean a ;
           int arr[] = new int[6];
           //int max = arr[0];
           int max;
           
           for(index=0; index<arr.length; index++)
           {
           arr[index]=rand.nextInt(100);
           
           }
           
           max = ArrayLesson_v003.findIndex(arr);//class
           
position = Arrays.binarySearch(arr, max);//the position of the array
           
   
for(index=0; index<arr.length; index++)
{
 System.out.printf("arr[%d]=%d\n",index,arr[index]);
}
a=Bool.T_or_F(arr);//a method declaration
System.out.println("Largest element present in given array: " + max);    
System.out.println("index: " + position);            



      
} 
      
     public static int findIndex(int[] arr){
     int max=arr[0];
           for(index = 0; index<arr.length; index++){  
            //Compare elements of array with max  
           if(arr[index] > max)  
               max = arr[index]; 
           
        } 
            
                       
return max;
  }
       
      
      
}//index of the highest value and true and false