package arraylesson_v003;

/**
 *
 * @author benie
 */
public class Boolean_T_and_F {

boolean T_or_F(int arr[])
{
   boolean a;

//for(index=0; index<arr.length; index++)
//{
      if(arr[0]>arr[1])
      {
           a = true;
       System.out.println(""+a);
      }
      else
      {
            a = false;
            System.out.println(""+a);
      }
    if(arr[2]>arr[3])
    {
          a = true;
          System.out.println(""+a);
    }
    else{
          a=false;
          System.out.println(""+a);
    }
    if(arr[4]>arr[5])
    {
          a=true;
          System.out.println(""+a);
    }
    else{
          a=false;
          System.out.println(""+a);
    }
//System.out.println(""+a);
     return a;
      
}
      
}
