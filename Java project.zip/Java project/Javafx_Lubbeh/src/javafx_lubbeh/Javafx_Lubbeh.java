
package javafx_lubbeh;

//import java.awt.Button;
//import javafx.application.Application;
//import javafx.stage.Stage;

//import java.awt.Button;
//import static java.awt.SystemColor.info;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
//import javafx.event.EventType;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.stage.Stage;

/**
 *
 * @author benie
 */
public class Javafx_Lubbeh extends Application{

String message ="DOWN" ;
String message2 = "Button pressed";
int increment = 0 ;
String info;
  
    public static void main(String[] args) {
     launch(args);
    }

     @Override
    public void start(Stage stage) throws Exception {
       // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        FlowPane layout = new FlowPane();
       
        Button btn1 = new Button("ButtomOne");
        TextField textField = new  TextField("UP");
        TextArea textArea = new TextArea("");
        Button btn2 = new Button("Buttomtwo");
        Button btn3 = new Button("ButtomThree");
        
       
         layout.getChildren().add(btn1);
      
         layout.getChildren().add(textField);
         layout.getChildren().add(textArea);
         //layout.getChildren().add(btn1);
         layout.getChildren().add(btn2);
         layout.getChildren().add(btn3);
  
            Scene scene = new Scene(layout,500,300);
        stage.setTitle("2023 javaFX");
        stage.setScene(scene);
        stage.show();
        
         btn1.setOnAction(new EventHandler<ActionEvent>() {

            public void handle(ActionEvent e) {
                System.out.println("hhhhh");
                
                message  = textField.getText();
                textField.setText(message);
                 //textField.setText();
                
            }
        });

        
          btn2.setOnAction(new EventHandler<ActionEvent>() {

            public void handle(ActionEvent e) {
               
                  
                  
                  
                  
                  
                  
            }
        });
          
          
      btn3.setOnAction(new EventHandler<ActionEvent>() {
              @Override
              public void handle(ActionEvent e) {
                    
             increment++;
             
          info =Integer.toString(increment);
          
           textField.setText(info);
                    
                    
                    
              }
        });
            
      
    }      
}
