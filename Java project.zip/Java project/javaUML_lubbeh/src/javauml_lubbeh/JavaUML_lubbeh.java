
package javauml_lubbeh;

/**
 *
 * @author benie
 */
public class JavaUML_lubbeh {

     

      public static void main(String[] args) {
            // TODO code application logic here
     ClassRoom obj = new ClassRoom();
     Room pc = Room();
     String output = obj.getColor();
     
//     Room bed = new Room();
//     Button keyboad = new Button();
//     keyboard.pressed();
     
System.out.printf("%s\n",output);
     
            
      }

      private static Room Room() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
      }
      
}


   