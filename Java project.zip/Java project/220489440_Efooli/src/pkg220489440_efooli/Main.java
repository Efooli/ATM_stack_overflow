
package pkg220489440_efooli;

/**
 *
 * @author 220489440
 */
public class Main{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Computer disk = new Computer();
        Computer chip = new Computer();
        memory_device AESD_24 = new memory_device();
       // CPU_chip CPU_chip1 = new CPU_chip();
        Solid_State_Hard_Disk   device = new Solid_State_Hard_Disk();
        AESD_24 pin = new AESD_24();
          String ar[] = new String[6];
          Cpu_chip chip new Cpu_chip();
          
          {
             Computer comp = new Computer(); 
          }
          
          {
             Cpu_chip chip new Cpu_chip();  
          }
        
        
        
        
        
    }
    
}
