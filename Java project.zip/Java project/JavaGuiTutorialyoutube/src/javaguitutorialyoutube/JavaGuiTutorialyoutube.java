//https://introcs.cs.princeton.edu/java/15inout/GUI/java.html
package javaguitutorialyoutube;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author benie
 */
public class JavaGuiTutorialyoutube implements ActionListener{
      
      int count =0;
      char alph ='a';
      JLabel label;
      JFrame frame;
      JPanel panel;

      public JavaGuiTutorialyoutube(){
      
      frame = new JFrame();
      panel = new JPanel();
      JButton button = new JButton("Click me");
      button.addActionListener(this);
      label = new JLabel("Number of clicks: 0");
      //label = new JLabel("Number of clicks: 0");
      
      
      
      
      panel.setBorder(BorderFactory.createEmptyBorder(30, 10, 30, 30));
      panel.setLayout(new GridLayout(6, 7));
      panel.add(button);
      panel.add(label);
      
      frame.add(panel, BorderLayout.CENTER);
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setTitle("OUR GUI");
      frame.pack();
      frame.setVisible(true);
      
      
      
      
}
      
      public static void main(String[] args) {
            new JavaGuiTutorialyoutube();
            
            
            
      }

      @Override
      public void actionPerformed(ActionEvent e) {
            //throw new UnsupportedOperationException("Not supported yet."); 
            
  count++;
  label.setText("Number of clicks: "+count);
  alph++;
  
  //label.setText("Number of clicks: "+alpha);
  
      }
      
}
