package arrayslubbeh;
import java.util.Random;//the random number class
import javax.swing.JOptionPane;
import java.util.Scanner;


public class Arrayslubbeh{

      static int index;
            public static void main(String[] args){
            
                int k;
    Random random = new Random();//this is random class
    
    Scanner scan = new Scanner(System.in);
     String name = JOptionPane.showInputDialog("please enter index number");
     int n = Integer.parseInt(name);
     
     //System.out.println("enter index");
     //int m = scan.nextInt();
     
     int[] arr = new int[n];
     //String[] arr = new String[5];
     //arr[1]=10;
     int c;
     System.out.println("Enter a number ");
     c= scan.nextInt();
     
     for(k=0; k<arr.length; k++){
                  arr[k] = random.nextInt(20)+1;
                 // arr[k]= random.nextInt(20)+"a";
                  arr[c]=c;
                  //arr[1]=10;
                  
            }
     
     
        
    for(int p=0; p<arr.length; p++){
                 System.out.printf("array[%d]=%d\n",p,arr[p]);
            }


      
     


      }
      
}
