package exception;
import java.util.*;
/**
 *
 * @author benie
 */
public class Exception {

      
       public static void main(String[] args) {
       int x=1;
             Scanner input = new Scanner(System.in);
            int num[] = new int[3];
             /*
             In this code the meaning of try and catch is that calculate but wherever there's a mistake instead of displaying the mistake statement on the console please display the message written by the user.
             */
             
             do{
             //try this if there's any error
             try{
               
             System.out.println("Please enter number 1: ");
             num[0] = input.nextInt();
             System.out.println("Please enter number 2: ");
             num[1] = input.nextInt();
             
             num[2] = num[0]/num[1];
             
             System.out.printf("Sum = %d\n",num[2]);
             x=2;//if this code run successfully x=2 wich means stop
             }
                          //do this, print this message
             catch(ArithmeticException e){
            System.out.println("This calculation can't be done");
             }
             catch(InputMismatchException e){
                   System.out.println("impossible");
             }
             }while(x==1);//if the code doesn't run successfully
              
       }
       
}
