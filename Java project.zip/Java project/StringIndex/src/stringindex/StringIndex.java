
package stringindex;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author benie
 */
public class StringIndex {

      
      public static void main(String[] args) {
            

StringIndex string = new StringIndex ();
    Scanner Obj = new Scanner(System.in);
        System.out.println("Enter any sentance here: ");
        String word = Obj.nextLine();
        string.search(word, 0);
    
ArrayList<Character> toPrint = new ArrayList<Character>();//the arrayList class 
        for (char c : word.toCharArray()) {
        toPrint.add(c);//the function to return a character
    }
        System.out.println(Arrays.toString(toPrint.toArray()));   

      }//=============End of the main method=============
      static void search(String word, int index) {
        char[] x = word.toCharArray();
        if (index != word.length()) {
            if (x[index] == 'A') {
                System.out.println("index: "+index);
            } else {
                  
                  
                index++;
               search(word, index);
            }
        }
    }
      
}
