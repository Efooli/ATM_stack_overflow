
package java2dgraphicyoutube;

/**
 *
 * @author benie
 */
public class Java2DgraphicYoutube {

      
      public static void main(String[] args) {
            
new = Myframe();
            
      }
      
}
