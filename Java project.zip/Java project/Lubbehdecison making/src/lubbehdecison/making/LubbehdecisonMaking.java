package lubbehdecison.making;
//import java.util.Arrays;
import java.util.Scanner;

public class LubbehdecisonMaking{
      

          public static void main(String[] args) {
          int n=5;
          
          
          
              //Scanner enter = new Scanner(System.in);
              LubbehdecisonMaking math = new LubbehdecisonMaking();
              String[] education = new String[n];
              //String[] names = new String[n];
             
             //s.namesDisplay(education);
             math.arrayList(education);
             math.namesDisplay(education);

           }
      //the method to do calculations and others      
            void arrayList(String[] education)
            {
             int add;
             
             int chances = 5;
             
          String name,user="yes";
          int x;
          Scanner enter = new Scanner(System.in);
          
          do{
           try{   
         System.out.println("Enter a number");
          add = enter.nextInt();
          chances--;
                       
                
           if(education[add]==null)
           {
                 System.out.println("What's your name");    
                 name = enter.next();
                 education[add]= name;
                 
                 //educationRd[2]=name;
                 System.out.println("do you want to continue?");
                 user = enter.next();
                 
             
                        
                 
           }
           
          else if(education[add].equals(education[add]))
         {
           
    System.out.println("this number has been assigned already");
    chances++;
             }
           
         if(chances == 0)
          {
      System.out.println("the program is full");
      System.out.printf("chances[%d]\n",chances);
      namesDisplay(education);
      System.exit(0);
      
      
          }
         }
           catch(ArrayIndexOutOfBoundsException e){
                 
System.out.println("Array Index Out Of Bounds Exception");
           }
                  
       
          
          }while(user.equalsIgnoreCase("yes"));
          
          
          
            }                                                                 
            
         // method display   
           void namesDisplay(String[] education)
           {
            for(int i=0; i<education.length; i++)
                 {
                  System.out.printf("[%d]=%s\n",i,education[i]);
                 }
     
            
           }                                                                 
 
}
