
package benigenerics;

/**
 *
 * @author benie
 */
public class Printer <T,P>{
      
      T name;
      P number;
      
      public Printer(T name, P number){
            this.name = name;
            this.number = number;
      }
      
      public void display(){
            
            System.out.printf("%s=%d",name,number);
      }
      
}
