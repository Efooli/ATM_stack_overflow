
package benigenerics;

import java.util.ArrayList;
import java.util.Iterator;

/**
 *
 * @author benie
 */
public class BeniGenerics {

      
      public static void main(String[] args) {
    
//Here, we are using the ArrayList class, but you can use any collection class such as ArrayList, LinkedList, HashSet, TreeSet, HashMap, Comparator etc.  

Printer<String,Integer> print = new Printer<>("Beni",7);
            print.display();
            
      }
      
}
