package sfd260class;

import java.awt.Color;
import java.awt.GridLayout;
import java.io.FileWriter;
import java.io.IOException;

 

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
//Beni Efooli
public class SFD260Class {

      
      public static void main(String[] args)throws IOException {
            JLabel label = new JLabel();
       JFrame frame = new JFrame("SFD 260 class");
      frame.setSize(800, 300);
      JPanel panel = new JPanel(new GridLayout(0,2));
      JLabel nameLab = new JLabel("Name:");
      JLabel surnameLab = new JLabel("Surname:");
      JLabel emailLab = new JLabel("Email:");
      JLabel phoneLab = new JLabel("Phone Number:");
      JLabel numberLab = new JLabel("Student Number:");
      JTextField nameTF = new JTextField();
      nameTF.setSize(50, 50);
      JTextField surnameTF = new JTextField();
      
      JTextField emailTF = new JTextField();
      JTextField phoneTF = new JTextField();
      JTextField numberTF = new JTextField();
      JButton button = new JButton("Submit");
      panel.add(nameLab);
      panel.add(nameTF);
      panel.add(surnameLab);
      panel.add(surnameTF);
      panel.add(emailLab);
      panel.add(emailTF);
      panel.add(phoneLab);
      panel.add(phoneTF);
      panel.add(numberLab);
      panel.add(numberTF);
      panel.add(button);
      frame.add(panel);
     
      button.addActionListener(e -> {FileWriter file = null;
          try {
              String name1 = nameTF.getText();
              nameTF.setText("");
              String surname1 = surnameTF.getText();
              String email1 = emailTF.getText();
              String phone1 = phoneTF.getText();
              String number1 = numberTF.getText();
             
              file = new FileWriter("C:\\Users\\benie\\OneDrive\\Documents\\SFD260\\List.txt", true);
              file.write(","+name1+","+surname1+","+"email1"+","+phone1+","+number1+"\n");
              file.close();
          } catch (IOException ex) {
              Logger.getLogger(SFD260Class.class.getName()).log(Level.SEVERE, null, ex);
          } finally {
              try {
                  file.close();
              } catch (IOException ex) {
                  Logger.getLogger(SFD260Class.class.getName()).log(Level.SEVERE, null, ex);
              }
          }
} );
      
      frame.setVisible(true);
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setLocationRelativeTo(null);   
     
            
            
      }
      
}
