
package bro_jlabel_swing;

import java.awt.Color;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.ImageIcon;

/**
 *
 * @author benie
 */
public class Bro_JLabel_swing {

      /**
       * @param args the command line
       * arguments
       */
      public static void main(String[] args) {
   // JLabel =is a GUI to display area for a string of text, an image, or both
   ImageIcon image = new ImageIcon("C:\\Users\\benie\\OneDrive\\Documents\\SFD260\\Cput.png");//image to be used 
   javax.swing.border.Border border = BorderFactory.createLineBorder(Color.BLACK,4);//setting the border of the image
   JLabel label = new JLabel();//create a label class
   label.setText("Bro, do you even code?");//set text of label
   label.setIcon(image);//setting the image of the frame according to your label
   label.setHorizontalTextPosition(JLabel.CENTER);// set the position of the text
   label.setVerticalTextPosition(JLabel.TOP);// set the position as well on top of the image
   label.setForeground(new Color(150, 100, 100));//changing text color
   label.setFont(new Font("MV Boli",Font.PLAIN,50));//set font of the text like zoom the text
   label.setIconTextGap(-100);//putting the text away from the image if you use a negative sign and positive sign close to the image.
   label.setBackground(Color.WHITE);//setting backgroung color
   label.setOpaque(true);//display background color
   label.setBorder(border);//setting the border of the image
   label.setVerticalAlignment(JLabel.CENTER);//setting the image and text in tthe center but vertical way
   label.setHorizontalAlignment(JLabel.CENTER);// setting the image and text in center but in horinzotal way.
   //label.setBounds(25, 25, 250, 250);//setting up the size of the border or label(x,Y,width,height)
   
   
   
   
   JFrame frame = new JFrame();//creating a frame
    
     frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//exit out of the application
     //frame.setSize(500,500);// sets the x-dimension and y-dimension
    //frame.setLayout(null);//abolishing and resetting everything to the initial
     frame.setVisible(true);//display the frame
     frame.setTitle("Beni JLabel");
     
     
     frame.add(label);//giving access to label to modify the content of the frame 
     frame.pack();//this will make the frame with the dimension as the same as the contents dimensions(according to your picture dimension)

            
            
      }
      
}
