
package efooli_220489440;

/**
 *
 * @author benie
 */
class Computer {
   
      Hard_Disk pin = new Hard_Disk();
      Cpu_chip chip = new Cpu_chip();
      
      void read(String array[]){
            
      }
      
      String write(){
            String array = null;
            
            return array;
      }
}
