
package efooli_220489440;

/**
 *
 * @author benie
 */
class Cpu_chip extends Computer{
     
      
}
