
package efooli_220489440;

/**
 *
 * @author benie
 */
class AESD_24 extends Memory_device{
      void read(String array[]){
            
      }
      
      String write(){
            String array = null;
            
            return array;
      }
      
}
