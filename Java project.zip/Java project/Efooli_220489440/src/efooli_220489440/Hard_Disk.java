
package efooli_220489440;

/**
 *
 * @author benie
 */
class Hard_Disk extends Computer{
      
      void read(String array[]){
            
      }
      
      String write(){
            String array = null;
            
            return array;
      }
                                                                                                          
}
