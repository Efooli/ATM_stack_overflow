package efooli_220489440;

/**
 *
 * @author benie
 */
class Memory_device {
      AESD_24 aesd = new AESD_24();
      
      void read(String array[]){
            
      }
      
      String write(){
            String array = null;
            
            return array;
      }
      
}
