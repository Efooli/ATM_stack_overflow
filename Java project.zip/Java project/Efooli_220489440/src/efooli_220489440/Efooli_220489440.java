
package efooli_220489440;
import java.util.*;

/**
 *
 * @author 220489440
 */
public class Efooli_220489440 {

      /**
       * @param args the command line
       * arguments
       */
      public static void main(String[] args) {
            // TODO code application logic here
         Computer device = new Computer();
         Memory_device memory = new Memory_device();
            String[] Array = new String[6];
         
      }
      
}
