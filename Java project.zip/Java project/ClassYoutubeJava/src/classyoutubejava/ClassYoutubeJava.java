package classyoutubejava;
import javax.swing.JOptionPane;
//import javax.swing.*;

/**
 *
 * @author benie
 */
public class ClassYoutubeJava {

      
      public static void main(String[] args) {
       
  String name = JOptionPane.showInputDialog("Enter your name");
  JOptionPane.showMessageDialog(null,"Hello "+name);
  //int age =Integer.parseInt(name);
  int age = Integer.parseInt(JOptionPane.showInputDialog("Enter your age")); 
JOptionPane.showMessageDialog(null,"you're "+age+" years old");

double height =Double.parseDouble(JOptionPane.showInputDialog("Enter your height")); 
JOptionPane.showMessageDialog(null,"you're "+height+" cm tall");

// Calculations section

int number1 = Integer.parseInt(JOptionPane.showInputDialog("Enter number1")); 


int number2 = Integer.parseInt(JOptionPane.showInputDialog("Enter number 2")); 

int number3 = number1 + number2;
JOptionPane.showMessageDialog(null,"answer="+number3);


       
              
      }
      
}
