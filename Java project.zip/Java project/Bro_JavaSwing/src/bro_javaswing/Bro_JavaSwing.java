//---------- introduction to swing --------
package bro_javaswing;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import java.awt.Color;
import java.util.Random;
//import javax.swing.*;
//import java.awt.*;
/**
 *
 * @author benie
 */
public class Bro_JavaSwing{
static int i;
      
      public static void main(String[] args) {
            // TODO code application logic here
      //JFrame = A GUI window to add components to 
      Random rand = new Random();
      int arr[] = new int[3];
      for(i=0; i<arr.length; i++){
            arr[i]=rand.nextInt(250);
      }
      
      
     JFrame frame = new JFrame();//creating a frame class
     //MyFrame myframe = new MyFrame();
     frame.setTitle("Java Swing Beni");//setting the title of the frame
     frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//exit out of the application
     frame.setResizable(false);//prevent frame from being resized. meaning you'll not reduce or increase the size of the frame with your cursor
     frame.setSize(420,420);// sets the x-dimension and y-dimension
     frame.setVisible(true);//make frame visible. this will display the frame
     ImageIcon image = new ImageIcon("C:\\Users\\benie\\OneDrive\\Documents\\SFD260\\Cput.png");//create an imageIcon logo
     frame.setIconImage(image.getImage());//change Icon  of the frame
     //frame.getContentPane().setBackground(Color.green);//change background color
     
     frame.getContentPane().setBackground(new Color(arr[0],arr[1],arr[2]));//change background color
     //frame.getContentPane().setBackground(new Color(100,200,100));//change background color
     
        
     
     
     
     
      }
      
}
