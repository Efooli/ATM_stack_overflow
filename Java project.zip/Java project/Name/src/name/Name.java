package name;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.shape.Line;
import javafx.stage.Stage;

/**
 *
 * @author Beni Efooli
 */
public class Name extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
    
        Line line = new Line();  
        line.setStartX(300); 
        line.setStartY(100);   
        line.setEndX(300);   
        line.setEndY(500);  
        Group root = new Group();  
        root.getChildren().add(line); 
        Scene scene = new Scene(root, 600, 600);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Line Example");
        primaryStage.show();

    }

    static void search(String word, int index) {
        char[] x = word.toCharArray();
        if (index != word.length()) {
            if (x[index] == 'A') {
                System.out.println(index);
            } else {
                index++;
                search(word, index);
            }
        }
    }

    public static void main(String[] args) {
        Scanner Obj = new Scanner(System.in);
        System.out.println("Enter any sentance here: ");
        String word = Obj.nextLine();
        search(word, 0);
        BufferedWriter writer;
        try {
            writer = new BufferedWriter(new FileWriter("UserText2.text", true));
            writer.append(' ');
            writer.append(word);
            writer.close();
        } catch (IOException ex) {
            Logger.getLogger(Name.class.getName()).log(Level.SEVERE, null, ex);
        }
      ArrayList<Character> toPrint = new ArrayList<Character>();
        for (char c : word.toCharArray()) {
        toPrint.add(c);
    }
        System.out.println(Arrays.toString(toPrint.toArray()));
        launch(args);
    }

}
