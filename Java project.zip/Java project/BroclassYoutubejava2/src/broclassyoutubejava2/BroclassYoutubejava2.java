//======== writing to a file youtube=======
package broclassyoutubejava2;

import java.util.Scanner;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;





/**
 *
 * @author benie
 */
public class BroclassYoutubejava2 {

      
public static int index;
      public static void main(String[] args) {
      BroclassYoutubejava2 objct = new BroclassYoutubejava2();
      
        Scanner Obj = new Scanner(System.in);
        System.out.println("Enter any sentance here: ");
        String word = Obj.nextLine();
        objct.searches(word, 0);
    
        ArrayList<Character> toPrint = new ArrayList<>();
        for (char c : word.toCharArray()) {
        toPrint.add(c);
    }
        try{
        
        FileWriter writer = new FileWriter("C:\\Users\\benie\\OneDrive\\Documents\\SFD260\\Prince_beni.csv");
        System.out.println(Arrays.toString(toPrint.toArray()));  
        writer.write(Arrays.toString(toPrint.toArray()));
         
        writer.append("\n\n(Beni le prince)");
          writer.close();
        }
        catch(IOException e){
              
         e.printStackTrace();     
        }
          
          
        
      }//end of main method
       

      private void searches(String word, int index) {
            
            char[] x = word.toCharArray();
        if (index != word.length()) {
            if (x[index] == 'A') {
                System.out.println(index);
              
            } else {
                index++;
                searches(word, index);
            }
        }
    }
            
            
      }