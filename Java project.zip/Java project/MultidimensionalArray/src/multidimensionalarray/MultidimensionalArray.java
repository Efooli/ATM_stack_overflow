/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package multidimensionalarray;

import java.util.Scanner;

/**
 *
 * @author benie
 */
public class MultidimensionalArray {

      /**
       * @param args the command line
       * arguments
       */
      public static void main(String[] args) {
            // TODO code application logic here
            Scanner scan = new Scanner(System.in);
///int i,j;
int arr[][] = new int[4][4];
//int value = 0;

int rows = 4;
        int columns = 4;
 
        int[][] array = new int[rows][columns];
 
        //int value = 1;
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                array[i][j] = scan.nextInt();
                //value++;
            }
        }
 
        System.out.println("The 2D array is: ");
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                
                System.out.printf("%d",array[i][j]);
            }
           System.out.println();
        }
           
      }
      
}
