/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package classmethod;

/**
 *
 * @author benie
 */
public class Classmethod {

    /**
     * @param args the command line arguments
     */

public int addnumber(int a, int b){


int c = a + b;

//System.out.println("sum is :\t" + c);

return (c);
}

int division(int k, int p){

int a = k + p;

return (a);
}


    public static void main(String[] args) {
        // TODO code application logic here
int k = 3;
int p = 6;
int b = 12;
int c;
Classmethod math = new Classmethod();
Classmethod physics = new Classmethod();

c = math.addnumber(physics.division(k,p),b);


System.out.println("sum is :\t" + c);

    }

}
