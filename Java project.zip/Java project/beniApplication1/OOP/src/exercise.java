
public class exercise extends calculator {

void display1(){


}


}
