/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author benie
 */
public class step2 {



void dog(){

System.out.println("eating...");


}



//int bonus = 10000;
void bark(){

System.out.println("stealing..."); 

} 


}
