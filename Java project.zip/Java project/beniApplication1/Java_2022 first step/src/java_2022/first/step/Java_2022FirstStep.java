package java_2022.first.step;
//import java.io.*;

//GUI = Graphical user interfaces
//import java.util.*; // This one will import everything that belongs to the class Scanner.
import java.util.Scanner;// we can use this one to scanning from the output or console. To scan a name
import javax.swing.JOptionPane;// we can use this one the two of them play the same role but this one is by using a GUI.
/**
 *
 * @author Beni Efooli

220489440
 */
public class Java_2022FirstStep {



    public static void main(String[] args) {
        // TODO code application logic here


//Java_2022FirstStep s1 = new Java_2022FirstStep(111,"Karan",500.23f);
//Java_2022FirstStep s2 = new Java_2022FirstStep(222,"Aryan",100.00f);
Java_2022FirstStep s = new Java_2022FirstStep();

Scanner in = new Scanner(System.in);

String name = JOptionPane.showInputDialog("Please enter your name\n");
String surname = JOptionPane.showInputDialog("please enter your surname\n");//method showInputDialog is specifically for string(scanf("%s",&surname);
//There are others methods which are used for intergers, float, double,... using GUI 

System.out.printf("my name is: %s\n my surname is %s\n",name,surname);
System.out.printf("you rock!\n\n");

System.out.println("Enter grade:\t");
int grade = in.nextInt();
System.out.printf("Grade = %d\n",grade);

int V=240,I=2;
s.menu();
//int p = s.power(240, 2);
//int p = s.power(V, I);
//System.out.printf("Power = %d\n",p);  
System.out.printf("Power = %d\n",s.power(V, I));  



 

   }//end of main method


void menu()
{
System.out.printf("you Beni!\n\n");

}//end of menu method

int power(int V, int I)
{
int p;

return(V*I);
}





}// end of the class java_2022Firststep
