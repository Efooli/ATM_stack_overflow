package javaapplication6;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author beni
 */
public class JavaApplication6 extends Application {
@Override
public void start(Stage stage)throws Exception{

Parent root = FXMLLoader.load(getClass().getResource("JavaApplication6.fxml"));

Scene scene = new Scene(root);
stage.setTitle("Draw Lines");
stage.setScene(scene);
stage.show();

}
  

    public static void main(String[] args) {
        // TODO code application logic here

launch(args);

    }

}
