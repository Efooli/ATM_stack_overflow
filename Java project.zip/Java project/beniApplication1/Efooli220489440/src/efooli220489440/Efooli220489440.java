package efooli220489440;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Sphere;
import javafx.stage.Stage;
/**
 *
 * @author benie
 */
public class Efooli220489440 extends Application{
@Override
    public void start(Stage primaryStage) throws Exception {
        Group layout = new Group();
        // CODE OF THE RECTANGLE START
        Rectangle rectangle = new Rectangle();
        rectangle.setTranslateX(20);
        rectangle.setTranslateY(20);
        rectangle.setHeight(50);
        rectangle.setWidth(100);
        rectangle.setFill(Color.RED);
        layout.getChildren().add(rectangle);
        //END
        
        Sphere spere = new Sphere();
        
        spere.setTranslateX(200);
        spere.setTranslateY(220);
        spere.setRadius(70);
        spere.setStyle("-fx-background-color: blue;");
        layout.getChildren().add(spere);
        Scene scene = new Scene(layout,800,600);
        primaryStage.setScene(scene);
        primaryStage.show();
}
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}