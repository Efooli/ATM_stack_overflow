package assignment;
import java.util.Scanner;

public class Assignment{
public String name;
public double average;
    
public Assignment(String name, double average){

this.name = name;

if (average > 0.0){

if(average <= 100){

this.average = average;

}
}


System.out.printf("%s 's letterGrade is : %s%n",setName(),getLetterGrade());
//System.out.printf("%s 's lettergrade is : %s%n",name,average);
}

public String setName(){

this.name = name;

return name;


}



public double setAverage(double studentAverage){

if(average > 0.0){
if(average <= 100){

this.average = average;
}

}
return average;
}



public String getLetterGrade(){

String letterGrade = "";

if (average >= 90){
letterGrade = "A";

}
else if(average >= 80){

letterGrade = "B";
}

else if(average >= 70){

letterGrade = "C";
}

else if(average >= 60){
letterGrade = "D";
}

else{

letterGrade = "E";

}
return letterGrade;


}

    public static void main(String[] args) {
        // TODO code application logic here

Scanner input = new Scanner(System.in);
 Assignment account1 = new Assignment("Beni",93.5);
Assignment account2 = new Assignment("Ena",75.3);
Assignment account3 = new Assignment("Efooli",40.3);

//System.out.printf("%s 's letterGrade is : %s%n",account1.setName(),account1.getLetterGrade());
//System.out.printf("%s 's lettergrade is : %s%n",account2.setName(),account2.getLetterGrade());
//System.out.printf("%s 's lettergrade is : %d%n",account3.setName(),account3.setAverage(studentAverage));
//account3.setName();
//account3.getLetterGrade();
//System.out.printf("%s 's letterGrade is : %s%n ",name,average);//System.out.printf("%s 's letterGrade

int total = 0;
int gradeCounter = 1;
int passes = 0;
int failures = 0;
int studentCounter = 1;
String name;
String letterGrade;

while(gradeCounter <=10){

System.out.println("Enter grade:\t");
int grade = input.nextInt();
total = total + grade;
//gradeCounter = gradeCounter + 1;
++gradeCounter;
}
int average = total /10;
System.out.printf("%nTotal of all 10 grades is %d%n", total);
System.out.printf("Class average is %d%n",average);

while(studentCounter <= 10){

System.out.print("Enter result (1 = pass, 2 = fail): ");
int result = input.nextInt();
if(result == 1){

passes = passes + 1;
}
else{

failures = failures + 1;
}
//studentCounter = studentCounter + 1;
studentCounter ++;
}

System.out.printf("passed:  %d%nfailed:  %d%n",passes,failures);

if(passes > 8){

System.out.println("Bonus to instructor");
}

    }

}
