package stringgwithadonis;
import java.util.Scanner;
import java.io.IOException;
//import java.io.FileNotFoundxception;

public class StringgwithAdonis{

   
 public static void main(String[] args) throws IOException {
        // TODO code application logic here
        
Scanner input = new Scanner(System.in);
System.out.println("please enter mark1: ");
String marks1 = input.next();

System.out.println("Please enter mark2: ");
String marks2 = input.next();

int sum = Integer.parseInt(marks1)/Integer.parseInt(marks2);
System.out.printf("sum = %d\n",sum);


        
}
  }
