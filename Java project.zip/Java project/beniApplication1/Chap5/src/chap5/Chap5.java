package chap5;
import java.util.Scanner;
/**
 *
 * @author benie
 */
public class Chap5 {




    public static void main(String[] args) {
        // TODO code application logic here
Scanner input = new Scanner(System.in);


int a = 3;
int b = 6;
int c;
//int selection = 0;
do{
    System.out.println("[1] Opition\n");
    System.out.println("[2] Opition\n");
    System.out.println("[3] Opition\n");
    System.out.println("[4] exit\n");
System.out.printf("Please make a selection:");
int selection = input.nextInt();
switch(selection){

case 1:
c = a + b;
System.out.printf("C:\t %d",c);
break;

case 2:
c = a * b;
System.out.printf("C:\t %d",c);
break;

case 3:
c = a / b;
System.out.printf("C:\t %d",c);
break;

case 4:
System.out.println("bye bye\n");
//exit(0);//this is for c programming
System.exit(0);
break;

default:
System.out.println("wrong selection\n");
break;




}
}while(input.hasNext());//while(selection !=5);



}
 }

/*
while(beni <= 3)
{

System.out.println("King's value");
int king = input.nextInt();
total = total + king;





++beni;


}
System.out.printf("the total is :\t %d%n",total);*/
//System.out.println();

/*for( beni = 1; beni <= 4; beni++){
System.out.println("King's value");
int king = input.nextInt();
total = total + king;

}
System.out.printf("the total is :\t %d%n",total);
*/


/*do{
System.out.println("King's value");
int king = input.nextInt();
total = total + king;



}while(beni <= 4);
System.out.printf("the total is :\t %d%n",total);

*/

/*int gradeCounter = 0;
int aCount = 0;
int bCount = 0;
int cCount = 0;
int dCount = 0;
int fCount = 0;

System.out.printf("%s%n%s%n    %s%n    %s%n","Enter the integer grades in the rang 0-100.","Type the end-of-file indicator to terminate input:","On UNIX/Linux/macOS type <Ctrl> d then press Enter","On Windows type <Ctrl> z then press Enter");

//loop until the user enters the end of file indicator
while(input.hasNext()){
int grade = input.nextInt();
total += grade;
++gradeCounter;

switch(grade / 10){

case 9:
case 10:
++aCount;
break;
case 8:
++bCount;
break;
case 7:
++cCount;
break;
case 6:
++dCount;
break;
default:
++fCount;
break;

}
}

System.out.printf("%nGrade Report:%n");
if(gradeCounter !=0){
double average = (double)total / gradeCounter;

System.out.printf("Total of the %d grades entered is %d%n",gradeCounter, total);
System.out.printf("Class average is %.2f%n",average);
System.out.printf("%n%s%n%s%d%s%s%n&d%s%n%d%n%s%n%d%s%n%d%n",
"A; ", aCount,
"B; ", bCount,
"C; ", cCount,
"D; ", dCount,
"F; ", fCount);

}
else{
System.out.println("No grades were entered");

}*/

/*
int a = 3;
int b = 6;
int c;
//int selection = 0;
do{
    System.out.println("[1] Opition\n");
    System.out.println("[2] Opition\n");
    System.out.println("[3] Opition\n");
    System.out.println("[4] exit\n");
int selection = input.nextInt();
switch(selection){

case 1:
c = a + b;
System.out.printf("C:\t %d",c);
break;

case 2:
c = a * b;
System.out.printf("C:\t %d",c);
break;

case 3:
c = a / b;
System.out.printf("C:\t %d",c);
break;

case 4:
System.out.println("bye bye\n");
//exit(0);
break;

default:
System.out.println("wrong selection\n");
break;




}
}while(input.hasNext());
*/