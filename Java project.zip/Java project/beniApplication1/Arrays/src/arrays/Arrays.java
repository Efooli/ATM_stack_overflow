/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package arrays;
import java.util.*;
/**
 *
 * @author benie
 */
public class Arrays {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

//Scanner input = new Scanner(System.in);
Arrays array = new Arrays();
//String name[] = new String[1];
////array.introarray(name);






/*
int age[];

age = new int[5];

age[0]=7;
age[1]=2;
age[2]=4;
age[3]=6;
age[4]=8;

for(int j=0; j<age.length; j++)
{

System.out.printf("array of age[%d]=%d\n",j,age[j]);
}
*/
/*
int age[] = {12, 4, 5 ,2, 5 };
int i;


//
System.out.println("Accessing Elements of Array:");
//System.out.println("first element" + age[0]);
for(i = 0; i<age.length; i++){

System.out.printf("%d\n",age[i]);
//System.out.printf("[%d %d %d %d %d]\n",age[0],age[1],age[2],age[3],age[4]);

}*/

/*int[] numbers = {2, -9, 0, 5, 12, -25, 22, 9, 8, 12};
int sum = 0;
Double average;

for (int number = 0; number < numbers.length; number++){
sum += number;
}
int arrayLength = numbers.length;

average = ((double)sum / (double)arrayLength);

System.out.println("Sum = " + sum);
System.out.println("Average = " + average);*/

/*int[][] a = { {1, 2, 3}, {4, 5, 6, 9},{7} };

for(int i=0; i < a.length ; i++){
for (int j=0; j < a[i].length ; j++){


System.out.println(a[i][j]); 
}
}*/

//System.out.println("the first row is \t:" + a[0].length);
//System.out.println("the first row is \t:" + a[1].length);
//System.out.println("the first row is \t:" + a[2].length);

/* int[][][] test = {
            {
              {1, -2, 3}, 
              {2, 3, 4}
            }, 
            { 
              {-4, -5, 6, 9}, 
              {1}, 
              {2, 3}
            } 
        }; 

        // for..each loop to iterate through elements of 3d array
        for (int[][] array2D: test) {
            for (int[] array1D: array2D) {
                for(int item: array1D) {
                    System.out.println(item);
                }
            }
        }

     */
// starting Adonis lessons about arrays

/*
 Scanner input = new Scanner(System.in);

//int[] array;
int total = 0;

int[] array = new int[5];
System.out.println("Enter array: ");
for(int i=0; i<array.length; i++)
{

array[i] = input.nextInt();
total = total + array[i];

}

System.out.printf("\ntotal = %d \n",total);

int remainder = 10%2;
System.out.printf("remainder is %d\n",remainder);
*/

   // TODO code application logic here
    }

          
    

}
