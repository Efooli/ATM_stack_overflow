/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package beniefooli;
import java.util.Scanner;

/**
 *
 * @author benie
 */
public class BeniEfooli {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {




Scanner input = new Scanner(System.in);

//int selection;

//System.out.println("1.OPTION");
//System.out.println("2.OPTION");
//int selection = nextInt();
//input.close();

//switch(selection)
//{
//case 1:
System.out.println("Enter a number\t: ");
float number = input.nextFloat();
//System.out.println("You entered\t"+number);

System.out.println("Enter the value of beni \t: ");
float Beni = input.nextFloat();
//System.out.println("You entered\t"+Beni);

float Ena = Beni + number;     //input.nextFloat();
//2Ena=Beni+number;

System.out.printf("Ena is :\t %f",Ena);

//Sleep(1000);
 //system('Cls');
//input.close();
//break;

//case 2:
//Scanner input = new Scanner(System.in);
System.out.println("\nEnter the value of cool \t: ");
float cool = input.nextFloat();
//System.out.println("You entered\t"+number);

System.out.println("Enter the value of Ben\t: ");
float Ben = input.nextFloat();
//System.out.println("You entered\t"+Beni);

float Efooli = input.nextFloat();
Efooli=Ben-cool;

System.out.println("Efooli is :\t"+Efooli);

input.close();

//break;

//default:
//System.out.println("wrong selection");
//input.close();
//}


//ent of switch
      // TODO code application logic here
    }

}
