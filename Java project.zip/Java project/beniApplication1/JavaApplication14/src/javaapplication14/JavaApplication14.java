/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package javaapplication14;
import java.util.Scanner;
/**
 *
 * @author benie
 */
public class JavaApplication14 {

    /**
     * @param args the command line arguments
     */
private String name;

public void setName(String name){

this.name = name;

}

public String getName(){

return name;
}


    public static void main(String[] args) {
        // TODO code application logic here


Scanner input = new Scanner(System.in);
JavaApplication14 myAccount = new JavaApplication14();

System.out.printf("The first value is :\t%s%n%n",myAccount.getName());

System.out.println("Enter the name:");
String theName = input.nextLine();
myAccount.setName(theName);
System.out.println();

System.out.printf("name in the Account is : %s%n%n",myAccount.getName());



    }

}






/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*
package constructor;
//import java.util.Scanner;
/**
 *
 * @author benie
 */
/*public class Constructor {

private String name ;

public Constructor(String name){

this.name = name;
}

public void setName(String name){
this.name = name;

//return name;
}
public String getName(){

return name;
}


  



    public static void main(String[] args) {
        // TODO code application logic here
 
  Constructor account1 = new Constructor("Beni");
  Constructor account2 = new Constructor("Ena");

System.out.printf("account1 name is : %s%n",account1.getName());
System.out.printf("account1 name is : %s%n",account2.getName());


    }

}
*/