/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*package javaapplication13;

/**
 *
 * @author benie
 */
/*public class JavaApplication13 {

    /**
     * @param args the command line arguments
     */
   /* public static void main(String[] args) {
        // TODO code application logic here
    }

}*/

package lubbe_436241263_summative_2_test;



import java.io.File;

import java.io.FileNotFoundException;

import java.io.FileOutputStream;

import java.io.OutputStream;

import java.util.ArrayList;

import java.util.Scanner;

import java.util.logging.Level;

import java.util.logging.Logger;

import javafx.application.Application;

import javafx.scene.Group;

import javafx.scene.Scene;

import javafx.scene.shape.LineTo;

import javafx.scene.shape.MoveTo;

import javafx.scene.shape.Path;

import javafx.stage.Stage;



/**

 *

 * @author Admin

 */
 
public class Lubbe_436241263_Summative_2_Test extends Application{



  /**

   * @param args the command line arguments

   */

  public static void main(String[] args) {

    launch(args);

    int indexPos;

    Scanner scan = new Scanner(System.in);

    String userIn;

    System.out.println("Give me a value:");

    userIn = scan.nextLine();

    indexPos = recursion(0,userIn);

    System.out.println("found at = " + indexPos);

    outputFile(userIn);

    testArrayList(userIn);

  }



  private static int recursion(int indexPos, String userIn) {

    int output;

     

/*    if(indexPos < userIn.length()){

      if(userIn.charAt(indexPos)=='A'){

        return indexPos;

      }else{

        indexPos++;

        output = recursion(indexPos,userIn);

        return output;

      }

    }else{

      return -1;

    }*/

     

    System.out.println("("+indexPos+") = " + userIn.charAt(indexPos) + " length = " + userIn.length());

    if(userIn.charAt(indexPos) == 'A'){       

      return indexPos;       

    }else{

      System.out.println("indexPos = " + indexPos);

      if(indexPos < (userIn.length()-1)){

        indexPos++;  

        System.out.println("index before recursion " + indexPos);

        output = recursion(indexPos, userIn);

        return output;

         

      }else{

        System.out.println("stoped with -1");

        output = -1;

        return output;

      }

    }

     

    

  }



  private static void outputFile(String userIn) {

    char stringOfChar[] = userIn.toCharArray();

    try {

    File file = new File("UserText2.txt");

    if(!file.exists()){

      file.createNewFile();

    }

     

      OutputStream outStream = new FileOutputStream(file);

      for(int count = 0; count < stringOfChar.length; count++){

        outStream.write(stringOfChar[count]);

      }

       

      outStream.close();

    } catch (Exception ex) {

      Logger.getLogger(Lubbe_436241263_Summative_2_Test.class.getName()).log(Level.SEVERE, null, ex);

    }

     

  }



  private static void testArrayList(String userIn) {

    ArrayList<Character> list = new ArrayList<Character>();

    for(int count = 0;count < userIn.length();count++){

      list.add(userIn.charAt(count));

    }

    System.out.println(list);

  }
}



  //@Override

  //public void start(Stage stage) throws Excep;

//Press Shift + Tab to navigate to chat history.