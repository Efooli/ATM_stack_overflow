package constructor;
import java.util.Scanner;
/**
 *
 * @author benie
 */
public class Constructor {
          
private String name ;
private double balance;

public Constructor(String name, double balance){

this.name = name;

if (balance > 0.0){

this.balance = balance;

}
System.out.printf("%s balance : $%f%n",getName(),getBalance());
//System.out.printf("%s balance : $%f%n",name,balance);// using this like you're negliging the methods
}


public void deposit(double depositAmount){

//double depositAmount;

if(depositAmount > 0.0){

this.balance = balance + depositAmount;
}

}

public double getBalance(){

return balance;
}

public void setName(String name){

//String nom = "Efooli";
//String name;
this.name = name;

}

public String getName(){


return name;
}

public double withdraw(double amount)
{
       if(amount>0.0)
       {
              this.balance = balance - amount;
       }
       
       return balance;
}

    public static void main(String[] args) {
        // TODO code application logic here
 
  Constructor account1 = new Constructor("Beni", 50.00);
  Constructor account2 = new Constructor("Ena", -73.53);
  
//System.out.printf("%s balance : $%2.f%n",account1.getName(),account1.getBalance());
//System.out.printf("%s balance : $%2.f%n",account2.getName(),account2.getBalance());


Scanner input = new Scanner(System.in);

System.out.print("depositAmaount of account1:\t");
double depositAmount = input.nextDouble();

System.out.printf("%nadding %f to account1 balance %n%n",depositAmount);
account1.deposit(depositAmount);

//System.out.println("Please enter your surname");
//String nom = input.next();
//System.out.println("%s surname to account1 setname %n%n",nom);
//account1.setName();


System.out.printf("%s balance : $%f%n",account1.getName(),account1.getBalance());
System.out.printf("%s balance : $%f%n",account2.getName(),account2.getBalance());


System.out.print("depositAmaount of account2:\t");
depositAmount = input.nextDouble();

System.out.printf("%nadding $%f to account2 balance %n%n",depositAmount);
account2.deposit(depositAmount);

System.out.printf("%s balance : $%f%n",account1.getName(),account1.getBalance());
System.out.printf("%s balance : $%f%n",account2.getName(),account2.getBalance());

System.out.println("Please Enter the amount to withdraw in account1 ");
float amount = input.nextFloat();
//double balance = account1.withdraw(amount);
System.out.printf("amount $%f\n",amount);
System.out.printf(" %s The balance is $%f\n",account1.getName(),account1.withdraw(amount));
System.out.printf("%s The balance is $%f\n",account2.getName(),account2.withdraw(amount));


System.out.println("Please Enter the amount to withdraw account2 ");
 amount = input.nextFloat();
//balance = account2.withdraw(amount);
System.out.printf("amount $%f\n",amount);
System.out.printf("%s The balance is $%f\n",account1.getName(),account1.withdraw(amount));
System.out.printf("%s The balance is $%f\n",account1.getName(),account2.withdraw(amount));
        


    }

}
