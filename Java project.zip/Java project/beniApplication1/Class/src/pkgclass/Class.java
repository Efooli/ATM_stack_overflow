/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package pkgclass;

/**
 *
 * @author benie
 */
class beni {

int Beni = 4;
int Prince = 7;
int king =5;
int queen ;

void Ena() {

int Beni = 4;
king = 5;
queen = Beni + king;

for(int i = 0 ; i > 1 ; i++) {
System.out.println(":\t" + queen);
//System.out.println("queen's value is");
}
//System.out.println("queen" + queen);
if (king > Beni)
{
System.out.println("high");
}
else if(king == Beni)
{
System.out.println(" equal ");
}



}

 void Efooli() {

Prince = 7;
System.out.println("Prince:\t" + Prince);

  }

}


public class Class {
    /**
     * @param args the command line arguments
     */



/*private static void beni(int a, int c, int b) {

c = a + b;

System.out.println(":\t" + c);*/


    public static void main(String[] args){


beni math = new beni();
beni physics = new beni();

math.Ena();
physics.Efooli();

        // TODO code application logic here
    }

}
