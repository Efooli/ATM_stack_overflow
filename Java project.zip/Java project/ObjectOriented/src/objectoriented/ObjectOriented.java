package objectoriented;

import java.util.Scanner;

/**
 *
 * @author benie
 */
public class ObjectOriented {

        /**
         * @param args the command line arguments
         */
        public static void main(String[] args) {
                // TODO code application logic here
                
                Scanner scan = new Scanner(System.in);
                
                Parent brakkies = new Parent();
        String myName;
        int from , to = 26;
        int count;
        System.out.println("Give me a value");
        from = scan.nextInt();
        
        System.out.println("What is your name");
        myName = scan.next();
        System.out.println("Hello " + myName + ". How are you doing");
                
        //brakkies.fetch();
        
        for(count = 0; count<10; count++){
         System.out.println("brakkies is counting for the " +count + "time");
            //count=count+1;
            count ++;
        brakkies.count();
        }
        
        System.out.println("Counting from last time");
        brakkies.count(from,to); 
                
                
                
  
                Son s = new Son();
                s.Ena();
                s.alphabet(from,to);
                
                grandSon gr = new grandSon();
                gr.reverse();
                //gr.Ena();
                
        }
        
}
