/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objectoriented;

//import java.io.PrintStream;
//import static java.lang.System.out;

/**
 *
 * @author benie
 */
public class Parent {
     void fetch(){
    
    }
    
    void count(int from, int to){
       int value;
       if(from > to){
       for(value = from; value > to; value--)
       {
           System.out.println(value);
       }
    }else{
    for(value = from; value < to; value++)
    {
        System.out.println(value);
    }
}
    
}
       
    

    void count() {
        
        int value;
       for(value = 0; value < 10; value++)
       {
           System.out.println(value);
       }
       
    }   
    
        
}
