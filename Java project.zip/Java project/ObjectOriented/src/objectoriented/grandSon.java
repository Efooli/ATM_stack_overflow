/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objectoriented;
import java.util.*;

/**
 *
 * @author benie
 */
public class grandSon{
       
       public void reverse()
       {
        Scanner input = new Scanner(System.in);
        System.out.println("\nPlease enter a name to reverse: ");
        String name = input.next();
        //int length=strlen(name)-1;
        char[]resultarray = name.toCharArray();
        
        System.out.println("\nthe reversed name: ");
        for(int i=resultarray.length-1; i>=0; i--)
        {
          //System.out.print(resultarray[i]);
               System.out.printf("%c", resultarray[i]);
          
        }
        
              
       }
       
       public void ascendingorder()
       {
              
             
       }
       
}
