package objectoriented;

/**
 *
 * @author benie
 */
public class Son {

        void Ena()
        {
          System.out.println("King Beni");
        }

        public void alphabet(int from, int to)
        {
            char alphabet = 'a';
            //int from,to;
            for(int i=from; i<=to; i++)
            {
                   System.out.printf("%c ",alphabet);
                   
                   alphabet++;
            }
        }
        
        
        
}
