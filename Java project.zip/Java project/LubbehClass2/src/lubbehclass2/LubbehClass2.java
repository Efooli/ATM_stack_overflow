package lubbehclass2;

import java.util.*;


public class LubbehClass2 {

      
      public static void main(String[] args) {
           
        Scanner sc = new Scanner(System.in);    
                
      // String age[];
       
String[] name = new String[3];
int j;
//name[0]="Beni";
//name[1]="Hello";
//name[2]="Good morning";
System.out.println("please enter the name");
for(j=0; j<name.length; j++)
{
      name[j] = sc.next();
}
for( j=0; j<name.length; j++)
{
System.out.printf("name[%d]=%s\n ",j,name[j]);
}

//System.getch();
//sc.nextLine();


int leftLimit = 97; // letter 'a'
    int rightLimit =122; // letter 'z'
    int targetStringLength = 10;
    Random random = new Random();

    for(int x=1;x<=100;x++) {
        StringBuilder buffer = new StringBuilder(targetStringLength);
    for (int i = 0; i < targetStringLength; i++) {
        int randomLimitedInt = leftLimit + random.nextInt(rightLimit - leftLimit + 1);
        buffer.append((char) randomLimitedInt);
    }
    String generatedString = buffer.toString();


    System.out.println(generatedString);

      }
      
}
}