package lubbehclass2;
import java.util.Random;
//import java.util.Arrays;



public class Randomarray {

    public void Random(){
 
      /*int k;
     Random random = new Random();
     int[] arr = new int[5];
     
     for(k=0; k<arr.length; k++){
                  arr[k] = random.nextInt(20)+1;
            }
     
 //    System.out.printf("%d\n %d\n %d\n %d\n %d\n",arr[0],arr[1],arr[2],arr[3],arr[4]);
     
        
    for(int p=0; p<arr.length; p++){
                 System.out.printf("array[%d]=%d\n",p,arr[p]);
            }*/
    Random random = new Random();
    System.out.println(random.nextBoolean());		
//It generates double value
System.out.println(random.nextDouble());		
		//It generates float value
System.out.println(random.nextFloat());		
		//It generates int value
System.out.println(random.nextInt());		
		//It generates int value within specific limit
System.out.println(random.nextInt(50));
    }
          
    }
    
   
